#!/bin/bash
#
#

function recurFunc()
{
    local dir=$1
    
    if [ -z "$dir" ]
    then
        dir="."
    fi
    
    for f in `ls $dir`
    do
        if [ -f "$dir/$f" ]
        then
            echo "$dir/$f is a file"
        elif [ -d "$dir/$f" ]
        then
            echo "$dir/$f is a directory"
            recurFunc "$dir/$f"
        else
            echo "$dir/$f is not recognized"
        fi
    done
}

recurFunc $1
