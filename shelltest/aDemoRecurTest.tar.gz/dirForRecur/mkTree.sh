#!/bin/bash
#

rm -r sh



mkdir -p sh/{a..f}/{a..g}/
touch sh/{a..f}/{a..g}/{1..10}.txt
tree -L 2


