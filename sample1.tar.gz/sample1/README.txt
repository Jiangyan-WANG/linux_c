make to install
make clean to uninstall

./readpt to open server
./writept to open client
